#pragma once
#include <math.h>

class Fatorial{
    public:
        Fatorial(){};
        ~Fatorial(){};
        int recursivo(int n);
        int iterativo(int n);
};
