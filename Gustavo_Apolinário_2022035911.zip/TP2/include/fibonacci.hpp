#pragma once

#include <math.h>

class Fibonacci{
    public:
        Fibonacci(){};
        ~Fibonacci(){};
        int recursivo(int n);
        int iterativo(int n);
};